﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace WpfApp1
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
       
        public MainWindow()
        {
           
            InitializeComponent();
            stop.IsEnabled = false;
            stop.Click += PressStop;
            start.Click += PressStart;
            this.KeyDown += Keys_Click;
            difficulty_slider.ValueChanged += SetDifficulty;
            LabelFails(Visibility.Hidden);
            ChangeGridState(false);
        }

        Brush qbr;

        bool isCapsLock = false;

        private void CapsLockTurnedOff()
        {
            q.Content = 'q';
            w.Content = 'w';
            r.Content = 'r';
            t.Content = 't';
            y.Content = 'y';
            u.Content = 'u';
            i.Content = 'i';
            o.Content = 'o';
            p.Content = 'p';
            a.Content = 'a';
            s.Content = 's';
            d.Content = 'd';
            f.Content = 'f';
            g.Content = 'g';
            h.Content = 'h';
            j.Content = 'j';
            k.Content = 'k';
            l.Content = 'l';
            z.Content = 'z';
            x.Content = 'x';
            c.Content = 'c';
            v.Content = 'v';
            b.Content = 'b';
            n.Content = 'n';
            m.Content = 'm';

            one.Content = '1';
            two.Content = '2';
            three.Content = '3';
            four.Content = '4';
            five.Content = '5';
            six.Content = '6';
            seven.Content = '7';
            eight.Content = '8';
            nine.Content = '9';
            zero.Content = '0';

            apostrof.Content = '`';
            minus.Content = '-';
            equals.Content = '=';

            suqare_brackets_open.Content = '[';
            suqare_brackets_close.Content = ']';
            backslash.Content = '\\';

            quotes.Content = " \"";

            semicolon.Content = ';';
            slash.Content = '/';

            dot.Content = '.';
            comma.Content = ',';

            isCapsLock = false;
        }

        private void LabelFails(Visibility visibility)
        {
            fails_label.Visibility = Visibility;
            fails = 0;
        }

        private void CapsLockTurnedOn()
        { 
            q.Content = 'Q';
            w.Content = 'W';
            r.Content = 'R';
            t.Content = 'T';
            y.Content = 'Y';
            u.Content = 'U';
            i.Content = 'I';
            o.Content = 'O';
            p.Content = 'P';
            a.Content = 'A';
            s.Content = 'S';
            d.Content = 'D';
            f.Content = 'F';
            g.Content = 'G';
            h.Content = 'H';
            j.Content = 'J';
            k.Content = 'K';
            l.Content = 'L';
            z.Content = 'Z';
            x.Content = 'X';
            c.Content = 'C';
            v.Content = 'V';
            b.Content = 'B';
            n.Content = 'N';
            m.Content = 'M';

            one.Content = '!';
            two.Content = '@';
            three.Content = '#';
            four.Content = '$';
            five.Content = '%';
            six.Content = '^';
            seven.Content = '&';
            eight.Content = '*';
            nine.Content = '(';
            zero.Content = ')';

            apostrof.Content = '~';
            minus.Content = '_';
            equals.Content = '+';

            suqare_brackets_open.Content = '{';
            suqare_brackets_close.Content = '}';
            backslash.Content = '|';

            semicolon.Content = ':';
            slash.Content = '?';

            quotes.Content = '\'';
            comma.Content = '<';

            dot.Content = '>';

            isCapsLock = true;
        }

        string first = @"Lorem Ipsum is simply dummy text of the printing and typesetting industry";
        string second = @"Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book";
        string third = @"It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum";
        private void PressStart(object sender, EventArgs e)
        {
            LabelFails(Visibility.Visible);
            stop.IsEnabled = true;
            start.IsEnabled = false;
            case_sensetive.IsEnabled = false;
            difficulty_slider.IsEnabled = false;
            ChangeGridState(true);
            SetDifficulty(sender, e);
            TimerStart();
        }

        private void ChangeGridState(bool flag)
        {
            row2.IsEnabled = flag;
            row3.IsEnabled = flag;
            row4.IsEnabled = flag;
            row5.IsEnabled = flag;
            row6.IsEnabled = flag;
        }

        private void SetDifficulty(object sender, EventArgs e)
        {
            if(difficulty_slider.Value>0 && difficulty_slider.Value<5)
            {
                main_text.Text = first;
            }
            else if (difficulty_slider.Value > 4 && difficulty_slider.Value < 8)
            {
                main_text.Text = second;
            }
            else if (difficulty_slider.Value > 8)
            {
                main_text.Text = third;
            }
        }

        private void PressStop(object sender, EventArgs e)
        {
            stop.IsEnabled = false;
            start.IsEnabled = true;
            case_sensetive.IsEnabled = true;
            difficulty_slider.IsEnabled = true;
            RestartTheGame(global_string);
            TimerStop();
           
        }

        

        private void RestartTheGame(string str)
        {

            MessageBox.Show("You completeed the task; Your score is " + speed_label.Content.ToString() + "/" + (fails+str.Length).ToString());
            ChangeGridState(false);
            stop.IsEnabled = false;
            start.IsEnabled = true;
            //difficulty_slider.Value = 0;
            case_sensetive.IsChecked = false;
            speed_label.Content = 0;
            fails = 0;
            success = 0;
        }

        Button previous_key = null;
        Brush previous;
        int fails = 0;
        int success = 0;
        string global_string;
        DispatcherTimer ticker;
        
        private void TimerStart()
        {
            ticker = new DispatcherTimer();
            ticker.IsEnabled = true;
            ticker.Interval = TimeSpan.FromSeconds(1);
            ticker.Tick += Ticker_Tick;
            ticker.Start();
        }

        private void TimerStop()
        {
            ticker.Stop();
            seconds = 30;
        }
        int seconds = 30;

        private void Ticker_Tick(object sender, EventArgs e)
        {
            if (seconds < 0)
            {
                RestartTheGame(global_string);
                TimerStop();
                return;
            }
            time_left.Content = seconds--; 
        }

        private void Keys_Click(object sender, KeyEventArgs ke)
        {

            string str = "";

            if (case_sensetive.IsChecked == false)
            {
                for (int i = 0; i < main_text.Text.Length; i++)
                {
                    str += char.ToLower(main_text.Text[0]);
                }
            }
            else
                str = main_text.Text;

            global_string = str;
            bool shift_flag = false;
            if (str == "")
            {
                RestartTheGame(str);
                TimerStop();
            }

            if(previous_key != null && previous_key.Content.ToString() == "Shift")
            {
                shift_flag = true;
            }
            if (previous_key != null)
            {
                previous_key.Background = previous;
            }

            bool flag = false;

            if (!isCapsLock)
            {
                switch (ke.Key)
                {

                    case Key.OemMinus:
                        {
                            previous = minus.Background;
                            previous_key = minus;
                            minus.Background = Brushes.Red;
                            if (str[0] == '_')
                            {
                                flag = true;
                            }
                        }
                        break;
                    case Key.OemBackslash:
                        {
                            previous = backslash.Background;
                            previous_key = backslash;
                            backslash.Background = Brushes.Red;
                            if (str[0] == '\\')
                            {
                                flag = true;
                            }
                        }
                        break;
                    case Key.OemSemicolon:
                        {
                            previous = semicolon.Background;
                            previous_key = semicolon;
                            semicolon.Background = Brushes.Red;
                            if (str[0] == ';')
                            {
                                flag = true;
                            }
                        }
                        break;
                    case Key.OemQuotes:
                        {
                            previous = quotes.Background;
                            previous_key = quotes;
                            quotes.Background = Brushes.Red;
                            if (str[0] == '\'')
                            {
                                flag = true;
                            }
                        }
                        break;
                    case Key.Return:
                        {
                            previous = enter.Background;
                            previous_key = enter;
                            enter.Background = Brushes.Red;
                            if (str[0] == '\n')
                            {
                                flag = true;
                            }
                        }
                        break;
                    case Key.RightAlt:
                        {
                            previous = right_alt.Background;
                            previous_key = right_alt;
                            right_alt.Background = Brushes.Red;
                            return;
                        }
                        break;
                    case Key.LeftAlt:
                        {
                            previous = left_alt.Background;
                            previous_key = left_alt;
                            left_alt.Background = Brushes.Red;
                            return;
                        }
                        break;
                    case Key.LeftCtrl:
                        {
                            previous = left_ctrl.Background;
                            previous_key = left_ctrl;
                            left_ctrl.Background = Brushes.Red;
                            return;
                        }
                        break;
                    case Key.RightCtrl:
                        {
                            previous = right_ctrl.Background;
                            previous_key = right_ctrl;
                            right_ctrl.Background = Brushes.Red;
                            return;
                        }
                        break;
                    case Key.OemTilde:
                        {
                            previous = apostrof.Background;
                            previous_key = apostrof;
                            apostrof.Background = Brushes.Red;
                            if (str[0] == '`')
                            {
                                flag = true;
                            }
                        }
                        break;
                    case Key.OemPlus:
                        {
                            previous = equals.Background;
                            previous_key = equals;
                            equals.Background = Brushes.Red;
                            if (str[0] == '=')
                            {
                                flag = true;
                            }
                        }
                        break;
                    case Key.OemPeriod:
                        {
                            previous = dot.Background;
                            previous_key = dot;
                            dot.Background = Brushes.Red;
                            if(str[0] == '.')
                            {
                                flag = true;
                            }
                        }
                        break;
                    case Key.OemComma:
                        {
                            previous = dot.Background;
                            previous_key = dot;
                            dot.Background = Brushes.Red;
                            if (str[0] == ',')
                            {
                                flag = true;
                            }
                        }
                        break;
                    case Key.OemQuestion:
                        {
                            previous = dot.Background;
                            previous_key = dot;
                            dot.Background = Brushes.Red;
                            if (str[0] == '?')
                            {
                                flag = true;
                            }
                        }
                        break;
                   
                    case Key.Q:
                        {
                            previous = q.Background;
                            previous_key = q;
                            q.Background = Brushes.Red;
                            if (str[0] == 'q')
                            {
                                flag = true;
                            }

                        }
                        break;
                    case Key.W:
                        {
                            previous = w.Background;
                            previous_key = w;
                            w.Background = Brushes.Red;
                            if (str[0] == 'w')
                            {
                                flag = true;
                            }

                        }
                        break;
                    case Key.E:
                        {
                            previous = e.Background;
                            previous_key = e;
                            e.Background = Brushes.Red;
                            if (str[0] == 'e')
                            {
                                flag = true;
                            }


                        }
                        break;
                    case Key.R:
                        {
                            previous = r.Background;
                            previous_key = r;
                            r.Background = Brushes.Red;
                            if (str[0] == 'r')
                            {
                                flag = true;
                            }

                        }
                        break;
                    case Key.T:
                        {
                            previous = t.Background;
                            previous_key = t;
                            t.Background = Brushes.Red;
                            if (str[0] == 't')
                            {
                                flag = true;
                            }


                        }
                        break;
                    case Key.Y:
                        {
                            previous = y.Background;
                            previous_key = y;
                            y.Background = Brushes.Red;
                            if (str[0] == 'y')
                            {
                                flag = true;
                            }
                        }
                        break;
                    case Key.U:
                        {
                            previous = u.Background;
                            previous_key = u;
                            u.Background = Brushes.Red;
                            if (str[0] == 'u')
                            {
                                flag = true;
                            }

                        }
                        break;
                    case Key.I:
                        {
                            previous = i.Background;
                            previous_key = i;
                            i.Background = Brushes.Red;
                            if (str[0] == 'i')
                            {
                                flag = true;
                            }
                        }
                        break;
                    case Key.O:
                        {
                            previous = o.Background;
                            previous_key = o;
                            o.Background = Brushes.Red;
                            if (str[0] == 'o')
                            {
                                flag = true;
                            }
                        }
                        break;
                    case Key.P:
                        {
                            previous = p.Background;
                            previous_key = p;
                            p.Background = Brushes.Red;
                            if (str[0] == 'p')
                            {
                                flag = true;
                            }
                        }
                        break;
                    case Key.A:
                        {
                            previous = a.Background;
                            previous_key = a;
                            a.Background = Brushes.Red;
                            if (str[0] == 'a')
                            {
                                flag = true;
                            }
                        }
                        break;
                    case Key.S:
                        {
                            previous = s.Background;
                            previous_key = s;
                            s.Background = Brushes.Red;
                            if (str[0] == 's')
                            {
                                flag = true;
                            }
                        }
                        break;
                    case Key.D:
                        {
                            previous = d.Background;
                            previous_key = d;
                            d.Background = Brushes.Red;
                            if (str[0] == 'd')
                            {
                                flag = true;
                            }
                        }
                        break;
                    case Key.F:
                        {
                            previous = f.Background;
                            previous_key = f;
                            f.Background = Brushes.Red;
                            if (str[0] == 'f')
                            {
                                flag = true;
                            }
                        }
                        break;
                    case Key.G:
                        {
                            previous = g.Background;
                            previous_key = g;
                            g.Background = Brushes.Red;
                            if (str[0] == 'g')
                            {
                                flag = true;
                            }
                        }
                        break;
                    case Key.H:
                        {
                            previous = h.Background;
                            previous_key = h;
                            h.Background = Brushes.Red;
                            if (str[0] == 'h')
                            {
                                flag = true;
                            }
                        }
                        break;
                    case Key.J:
                        {
                            previous = j.Background;
                            previous_key = j;
                            j.Background = Brushes.Red;
                            if (str[0] == 'j')
                            {
                                flag = true;
                            }
                        }
                        break;
                    case Key.K:
                        {
                            previous = k.Background;
                            previous_key = k;
                            k.Background = Brushes.Red;
                            if (str[0] == 'k')
                            {
                                flag = true;
                            }
                        }
                        break;
                    case Key.L:
                        {
                            previous = l.Background;
                            previous_key = l;
                            l.Background = Brushes.Red;
                            if (str[0] == 'l')
                            {
                                flag = true;
                            }
                        }
                        break;
                    case Key.Z:
                        {
                            previous = z.Background;
                            previous_key = z;
                            z.Background = Brushes.Red;
                            if (str[0] == 'z')
                            {
                                flag = true;
                            }
                        }
                        break;
                    case Key.X:
                        {
                            previous = x.Background;
                            previous_key = x;
                            x.Background = Brushes.Red;
                            if (str[0] == 'x')
                            {
                                flag = true;
                            }
                        }
                        break;
                    case Key.C:
                        {
                            previous = c.Background;
                            previous_key = c;
                            c.Background = Brushes.Red;
                            if (str[0] == 'c')
                            {
                                flag = true;
                            }
                        }
                        break;
                    case Key.V:
                        {
                            previous = v.Background;
                            previous_key = v;
                            v.Background = Brushes.Red;
                            if (str[0] == 'v')
                            {
                                flag = true;
                            }
                        }
                        break;
                    case Key.B:
                        {
                            previous = b.Background;
                            previous_key = b;
                            b.Background = Brushes.Red;
                            if (str[0] == 'b')
                            {
                                flag = true;
                            }
                        }
                        break;
                    case Key.N:
                        {
                            previous = n.Background;
                            previous_key = n;
                            n.Background = Brushes.Red;
                            if (str[0] == 'n')
                            {
                                flag = true;
                            }
                        }
                        break;
                    case Key.M:
                        {
                            previous = m.Background;
                            previous_key = m;
                            m.Background = Brushes.Red;
                            if (str[0] == 'm')
                            {
                                flag = true;
                            }
                        }
                        break;
                    case Key.Space:
                        {
                            previous = Spacebar.Background;
                            previous_key = Spacebar;
                            Spacebar.Background = Brushes.Red;
                            if (str[0] == ' ')
                            {
                                flag = true;
                            }
                        }
                        break;
                    case Key.Tab://
                        {
                            previous = tab.Background;
                            previous_key = tab;
                            tab.Background = Brushes.Red;
                            if (str.Substring(0, 4) == "    ")
                            {
                                main_text.Text = main_text.Text.Substring(3);
                                return;
                            }
                        }
                        break;
                    case Key.CapsLock://
                        {
                            if (case_sensetive.IsChecked == true)
                            {
                                if (!isCapsLock)
                                    CapsLockTurnedOn();
                                else
                                    CapsLockTurnedOff();
                            }
                            previous = CapsLock.Background;
                            previous_key = CapsLock;
                            CapsLock.Background = Brushes.Red;
                            return;
                        }
                        break;
                    case Key.D1:
                        {

                            previous = one.Background;
                            previous_key = one;
                            one.Background = Brushes.Red;
                            if (str[0] == '1')
                            {
                                flag = true;
                            }
                        }
                        break;
                    case Key.D2:
                        {

                            previous = two.Background;
                            previous_key = two;
                            two.Background = Brushes.Red;
                            if (str[0] == '2')
                            {
                                flag = true;
                            }
                        }
                        break;
                    case Key.D3:
                        {
                            previous = three.Background;
                            previous_key = three;
                            three.Background = Brushes.Red;
                            if (str[0] == '3')
                            {
                                flag = true;
                            }
                        }
                        break;
                    case Key.D4:
                        {
                            previous = four.Background;
                            previous_key = four;
                            four.Background = Brushes.Red;
                            if (str[0] == '4')
                            {
                                flag = true;
                            }
                        }
                        break;
                    case Key.D5:
                        {
                            previous = five.Background;
                            previous_key = five;
                            five.Background = Brushes.Red;
                            if (str[0] == '5')
                            {
                                flag = true;
                            }
                        }
                        break;
                    case Key.D6:
                        {
                            previous = six.Background;
                            previous_key = six;
                            six.Background = Brushes.Red;
                            if (str[0] == '6')
                            {
                                flag = true;
                            }
                        }
                        break;
                    case Key.D7:
                        {
                            previous = seven.Background;
                            previous_key = seven;
                            seven.Background = Brushes.Red;
                            if (str[0] == '7')
                            {
                                flag = true;
                            }
                        }
                        break;
                    case Key.D8:
                        {
                            previous = eight.Background;
                            previous_key = eight;
                            eight.Background = Brushes.Red;
                            if (str[0] == '8')
                            {
                                flag = true;
                            }
                        }
                        break;
                    case Key.D9:
                        {
                            previous = nine.Background;
                            previous_key = nine;
                            nine.Background = Brushes.Red;
                            if (str[0] == '9')
                            {
                                flag = true;
                            }
                        }
                        break;
                    case Key.D0:
                        {
                            previous = zero.Background;
                            previous_key = zero;
                            zero.Background = Brushes.Red;
                            if (str[0] == '0')
                            {
                                flag = true;
                            }
                        }
                        break;
                    case Key.OemOpenBrackets:
                        {
                            previous = suqare_brackets_open.Background;
                            previous_key = suqare_brackets_open;
                            suqare_brackets_open.Background = Brushes.Red;
                            if (str[0] == '[')
                            {
                                flag = true;
                            }
                        }
                        break;
                    case Key.OemCloseBrackets:
                        {
                            previous = suqare_brackets_close.Background;
                            previous_key = suqare_brackets_close;
                            suqare_brackets_close.Background = Brushes.Red;
                            if (str[0] == ']')
                            {
                                flag = true;
                            }
                        }
                        break;
                    case Key.LeftShift:
                        {
                            previous = left_shift.Background;
                            previous_key = left_shift;
                            left_shift.Background = Brushes.Red;
                            if (case_sensetive.IsChecked == true)
                                CapsLockTurnedOn();

                        }
                        break;
                    case Key.RightShift:
                        {
                            previous = right_shift.Background;
                            previous_key = right_shift;
                            right_shift.Background = Brushes.Red;
                            if (case_sensetive.IsChecked == true)
                                CapsLockTurnedOn();

                        }
                        break;
                   
                        break;
                    case Key.LWin:
                        {
                            previous = left_win.Background;
                            previous_key = left_win;
                            left_win.Background = Brushes.Red;


                        }
                        break;
                    case Key.RWin:
                        {
                            previous = right_win.Background;
                            previous_key = right_win;
                            right_win.Background = Brushes.Red;
                        }
                        break;
                  
                   
                }
            }
            else
            {
                switch (ke.Key)
                {
                       
                    case Key.Q:
                        {
                            previous = q.Background;
                            previous_key = q;
                            q.Background = Brushes.Red;
                            if (str[0] == 'Q')
                            {
                                flag = true;
                            }

                        }
                        break;
                    case Key.W:
                        {
                            previous = w.Background;
                            previous_key = w;
                            w.Background = Brushes.Red;
                            if (str[0] == 'W')
                            {
                                flag = true;
                            }

                        }
                        break;
                    case Key.E:
                        {
                            previous = e.Background;
                            previous_key = e;
                            e.Background = Brushes.Red;
                            if (str[0] == 'E')
                            {
                                flag = true;
                            }


                        }
                        break;
                    case Key.R:
                        {
                            previous = r.Background;
                            previous_key = r;
                            r.Background = Brushes.Red;
                            if (str[0] == 'R')
                            {
                                flag = true;
                            }

                        }
                        break;
                    case Key.T:
                        {
                            previous = t.Background;
                            previous_key = t;
                            t.Background = Brushes.Red;
                            if (str[0] == 'T')
                            {
                                flag = true;
                            }


                        }
                        break;
                    case Key.Y:
                        {
                            previous = y.Background;
                            previous_key = y;
                            y.Background = Brushes.Red;
                            if (str[0] == 'Y')
                            {
                                flag = true;
                            }
                        }
                        break;
                    case Key.U:
                        {
                            previous = u.Background;
                            previous_key = u;
                            u.Background = Brushes.Red;
                            if (str[0] == 'U')
                            {
                                flag = true;
                            }

                        }
                        break;
                    case Key.I:
                        {
                            previous = i.Background;
                            previous_key = i;
                            i.Background = Brushes.Red;
                            if (str[0] == 'I')
                            {
                                flag = true;
                            }
                        }
                        break;
                    case Key.O:
                        {
                            previous = o.Background;
                            previous_key = o;
                            o.Background = Brushes.Red;
                            if (str[0] == 'O')
                            {
                                flag = true;
                            }
                        }
                        break;
                    case Key.P:
                        {
                            previous = p.Background;
                            previous_key = p;
                            p.Background = Brushes.Red;
                            if (str[0] == 'P')
                            {
                                flag = true;
                            }
                        }
                        break;
                    case Key.A:
                        {
                            previous = a.Background;
                            previous_key = a;
                            a.Background = Brushes.Red;
                            if (str[0] == 'A')
                            {
                                flag = true;
                            }
                        }
                        break;
                    case Key.S:
                        {
                            previous = s.Background;
                            previous_key = s;
                            s.Background = Brushes.Red;
                            if (str[0] == 'S')
                            {
                                flag = true;
                            }
                        }
                        break;
                    case Key.D:
                        {
                            previous = d.Background;
                            previous_key = d;
                            d.Background = Brushes.Red;
                            if (str[0] == 'D')
                            {
                                flag = true;
                            }
                        }
                        break;
                    case Key.F:
                        {
                            previous = f.Background;
                            previous_key = f;
                            f.Background = Brushes.Red;
                            if (str[0] == 'F')
                            {
                                flag = true;
                            }
                        }
                        break;
                    case Key.G:
                        {
                            previous = g.Background;
                            previous_key = g;
                            g.Background = Brushes.Red;
                            if (str[0] == 'G')
                            {
                                flag = true;
                            }
                        }
                        break;
                    case Key.H:
                        {
                            previous = h.Background;
                            previous_key = h;
                            h.Background = Brushes.Red;
                            if (str[0] == 'H')
                            {
                                flag = true;
                            }
                        }
                        break;
                    case Key.J:
                        {
                            previous = j.Background;
                            previous_key = j;
                            j.Background = Brushes.Red;
                            if (str[0] == 'J')
                            {
                                flag = true;
                            }
                        }
                        break;
                    case Key.K:
                        {
                            previous = k.Background;
                            previous_key = k;
                            k.Background = Brushes.Red;
                            if (str[0] == 'K')
                            {
                                flag = true;
                            }
                        }
                        break;
                    case Key.L:
                        {
                            previous = l.Background;
                            previous_key = l;
                            l.Background = Brushes.Red;
                            if (str[0] == 'L')
                            {
                                flag = true;
                            }
                        }
                        break;
                    case Key.Z:
                        {
                            previous = z.Background;
                            previous_key = z;
                            z.Background = Brushes.Red;
                            if (str[0] == 'Z')
                            {
                                flag = true;
                            }
                        }
                        break;
                    case Key.X:
                        {
                            previous = x.Background;
                            previous_key = x;
                            x.Background = Brushes.Red;
                            if (str[0] == 'X')
                            {
                                flag = true;
                            }
                        }
                        break;
                    case Key.C:
                        {
                            previous = c.Background;
                            previous_key = c;
                            c.Background = Brushes.Red;
                            if (str[0] == 'C')
                            {
                                flag = true;
                            }
                        }
                        break;
                    case Key.V:
                        {
                            previous = v.Background;
                            previous_key = v;
                            v.Background = Brushes.Red;
                            if (str[0] == 'V')
                            {
                                flag = true;
                            }
                        }
                        break;
                    case Key.B:
                        {
                            previous = b.Background;
                            previous_key = b;
                            b.Background = Brushes.Red;
                            if (str[0] == 'B')
                            {
                                flag = true;
                            }
                        }
                        break;
                    case Key.N:
                        {
                            previous = n.Background;
                            previous_key = n;
                            n.Background = Brushes.Red;
                            if (str[0] == 'N')
                            {
                                flag = true;
                            }
                        }
                        break;
                    case Key.M:
                        {
                            previous = m.Background;
                            previous_key = m;
                            m.Background = Brushes.Red;
                            if (str[0] == 'M')
                            {
                                flag = true;
                            }
                        }
                        break;
                    case Key.Space:
                        {
                            previous = Spacebar.Background;
                            previous_key = Spacebar;
                            Spacebar.Background = Brushes.Red;
                            if (str[0] == ' ')
                            {
                                flag = true;
                            }
                        }
                        break;
                    case Key.Tab://
                        {
                            previous = tab.Background;
                            previous_key = tab;
                            tab.Background = Brushes.Red;
                            if (str.Substring(0, 4) == "    ")
                            {
                                main_text.Text = main_text.Text.Substring(3);
                                return;
                            }
                        }
                        break;
                    case Key.CapsLock://
                        {
                            if (case_sensetive.IsChecked == true)
                            {
                                if (!isCapsLock)
                                    CapsLockTurnedOn();
                                else
                                    CapsLockTurnedOff();
                            }
                            previous = CapsLock.Background;
                            previous_key = CapsLock;
                            CapsLock.Background = Brushes.Red;
                            return;
                        }
                        break;
                    case Key.OemTilde:
                        {

                            previous = apostrof.Background;
                            previous_key = apostrof;
                            apostrof.Background = Brushes.Red;
                            if (str[0] == '~')
                            {
                                flag = true;
                            }
                        }
                        break;
                    case Key.Oem1:
                        {

                            previous = one.Background;
                            previous_key = one;
                            one.Background = Brushes.Red;
                            if (str[0] == '!')
                            {
                                flag = true;
                            }
                        }
                        break;
                    case Key.Oem2:
                        {

                            previous = two.Background;
                            previous_key = two;
                            two.Background = Brushes.Red;
                            if (str[0] == '@')
                            {
                                flag = true;
                            }
                        }
                        break;
                    case Key.D3:
                        {
                            previous = three.Background;
                            previous_key = three;
                            three.Background = Brushes.Red;
                            if (str[0] == '$')
                            {
                                flag = true;
                            }
                        }
                        break;
                    case Key.Oem4:
                        {
                            previous = four.Background;
                            previous_key = four;
                            four.Background = Brushes.Red;
                            if (str[0] == '$')
                            {
                                flag = true;
                            }
                        }
                        break;
                    case Key.Oem5:
                        {
                            previous = five.Background;
                            previous_key = five;
                            five.Background = Brushes.Red;
                            if (str[0] == '%')
                            {
                                flag = true;
                            }
                        }
                        break;
                    case Key.Oem6:
                        {
                            previous = six.Background;
                            previous_key = six;
                            six.Background = Brushes.Red;
                            if (str[0] == '^')
                            {
                                flag = true;
                            }
                        }
                        break;
                    case Key.Oem7:
                        {
                            previous = seven.Background;
                            previous_key = seven;
                            seven.Background = Brushes.Red;
                            if (str[0] == '&')
                            {
                                flag = true;
                            }
                        }
                        break;
                    case Key.Oem8:
                        {
                            previous = eight.Background;
                            previous_key = eight;
                            eight.Background = Brushes.Red;
                            if (str[0] == '*')
                            {
                                flag = true;
                            }
                        }
                        break;
                    case Key.OemMinus:
                        {
                            previous = nine.Background;
                            previous_key = nine;
                            nine.Background = Brushes.Red;
                            if (str[0] == '-')
                            {
                                flag = true;
                            }
                        }
                        break;
                    case Key.OemPlus:
                        {
                            previous = zero.Background;
                            previous_key = zero;
                            zero.Background = Brushes.Red;
                            if (str[0] == '+')
                            {
                                flag = true;
                            }
                        }
                        break;
                    case Key.OemComma:
                        {
                            previous = comma.Background;
                            previous_key = comma;
                            comma.Background = Brushes.Red;
                            if (str[0] == ',')
                            {
                                flag = true;
                            }
                        }
                        break;
                    case Key.LeftShift:
                        {
                            previous = left_shift.Background;
                            previous_key = left_shift;
                            left_shift.Background = Brushes.Red;
                            if (case_sensetive.IsChecked == true)
                                CapsLockTurnedOn();

                        }
                        break;
                    case Key.RightShift:
                        {
                            previous = right_shift.Background;
                            previous_key = right_shift;
                            right_shift.Background = Brushes.Red;
                            if (case_sensetive.IsChecked == true)
                                CapsLockTurnedOn();

                        }
                        break;
                    case Key.LeftCtrl:
                        {
                            previous = left_ctrl.Background;
                            previous_key = left_ctrl;
                            left_ctrl.Background = Brushes.Red;


                        }
                        break;
                    case Key.RightCtrl:
                        {
                            previous = right_ctrl.Background;
                            previous_key = right_ctrl;
                            right_ctrl.Background = Brushes.Red;


                        }
                        break;
                    case Key.LWin:
                        {
                            previous = left_win.Background;
                            previous_key = left_win;
                            left_win.Background = Brushes.Red;


                        }
                        break;
                    case Key.RWin:
                        {
                            previous = right_win.Background;
                            previous_key = right_win;
                            right_win.Background = Brushes.Red;
                        }
                        break;
                    case Key.LeftAlt:
                        {
                            previous = left_alt.Background;
                            previous_key = left_alt;
                            left_alt.Background = Brushes.Red;
                        }
                        break;
                    case Key.RightAlt:
                        {
                            previous = right_alt.Background;
                            previous_key = right_alt;
                            right_alt.Background = Brushes.Red;
                        }
                        break;
                    case Key.OemPeriod:
                        {
                            previous = dot.Background;
                            previous_key = dot;
                            dot.Background = Brushes.Red;
                            if(str[0]=='.')
                            {
                                
                                 flag = true;
                                
                            }
                        }
                        break;
                }
            }

            if(shift_flag == true)
            {
                CapsLockTurnedOff();
            }

            if(flag == true && ke.Key == Key.Tab)
            {
                main_text.Text = main_text.Text.Substring(3);
            }
            else if (flag == true)
            {
                main_text.Text = main_text.Text.Substring(1);
                speed_label.Content = ++success;

            }
            else
            {
                fails_label.Content = ++fails;
            }
        }
    }
}
